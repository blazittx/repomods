# More Commands
- /Commands that can be used from the TTS Chat
- Client side so you do not need any other friends to have it!
## List Of Commands
- **RESPAWN**:
    - **/respawnall**: Will respawn all players which are dead. If the dead head is available will respawn the player at that position. If not the players will be respawned at the cart.
- **MONEY**:
    - **/money**: Will spawn a small valuable infront of the player. Can be useful if the game gets softlocked because all loot is broken.
- **HEALTH**:
    - **/sethealth value**: Will set the health of the player to the given value.
- **GOD MODE**:
    - **/god on/off**: Will turn on god mode for the player.
